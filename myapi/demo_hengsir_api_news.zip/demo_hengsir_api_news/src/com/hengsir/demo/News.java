package com.hengsir.demo;


public class News {

	private String newsName;//新闻标题
	private String newsHref;//新闻的链接
	
	public String getNewsName() {
		return newsName;
	}
	public void setNewsName(String newsName) {
		this.newsName = newsName;
	}
	public String getNewsHref() {
		return newsHref;
	}
	public void setNewsHref(String newsHref) {
		this.newsHref = newsHref;
	}

}
