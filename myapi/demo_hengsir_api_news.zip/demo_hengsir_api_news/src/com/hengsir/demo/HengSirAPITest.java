package com.hengsir.demo;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class HengSirAPITest {
	public static void main(String[] args) {
		try {
			List<News> list = getNews("科技");
			if (list != null) {
				for (News news : list) {
					System.out.println("news:" + news.getNewsName());
					System.out.println(news.getNewsHref());
				}
			} else {
				System.out.println("...");
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static List<News> getNews(String type) throws IOException {

		String param = URLEncoder.encode(type, "utf-8");
		String url = "http://www.hengsir.cn:8080/hengsir_api/news.do?type=" + param;

		BufferedReader in = null;
		List<News> newsList = null;
		String respJson = "";// 响应回来的内容为json

		URL reqUrl = new URL(url);
		HttpURLConnection conn = (HttpURLConnection) reqUrl.openConnection();
		conn.connect();

		in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));

		String line = "";
		while ((line = in.readLine()) != null) {
			respJson += line;
		}

		// 使用gson包解析json对象
		//这里需要导入gson-2.8.0.jar这个包。
		Gson gson = new Gson();
		if (respJson.length() > 5) {
			Type t = new TypeToken<ArrayList<News>>() {
			}.getType();
			newsList = gson.fromJson(respJson, t);
			return newsList;
		}

		if (in != null) {
			in.close();
		}

		return null;
	}
}
